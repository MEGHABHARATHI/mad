package com.example.exercise3;

import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Handler;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Random;

public class MainActivity extends AppCompatActivity {
    private Button playPauseButton, prevButton, nextButton;
    private SeekBar seekBar;
    private TextView textView;
    private MediaPlayer mediaPlayer;
    private int currentSongIndex = 0;
    private Handler handler = new Handler();
    private boolean isShuffle = false, isRepeat = false;

    private int[] songs = { R.raw.chellamma_sollu_sollu, R.raw.para_para, R.raw.vathi_raid };
    private String[] songTitles = {"Chellamma Sollu Sollu", "Para Para", "Vaathi Raid"};


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize UI elements
        playPauseButton = findViewById(R.id.playPause);
        prevButton = findViewById(R.id.prev);
        nextButton = findViewById(R.id.next);
        seekBar = findViewById(R.id.seekBar);
        textView = findViewById(R.id.textView);

        initializeMediaPlayer();

        playPauseButton.setOnClickListener(v -> togglePlayPause());
        nextButton.setOnClickListener(v -> playNextSong());
        prevButton.setOnClickListener(v -> playPreviousSong());

        mediaPlayer.setOnCompletionListener(mp -> {
            if (isRepeat) {
                initializeMediaPlayer();
                mediaPlayer.start();
            } else {
                playNextSong();
            }
        });

        updateSeekBar();
    }

    private void initializeMediaPlayer() {
        if (mediaPlayer != null) {
            mediaPlayer.release();
        }
        mediaPlayer = MediaPlayer.create(this, songs[currentSongIndex]);
        textView.setText(songTitles[currentSongIndex]);
        seekBar.setMax(mediaPlayer.getDuration());
    }

    private void togglePlayPause() {
        if (mediaPlayer == null) return;
        if (mediaPlayer.isPlaying()) {
            mediaPlayer.pause();
            playPauseButton.setBackgroundResource(R.drawable.ic_play);
        } else {
            mediaPlayer.start();
            playPauseButton.setBackgroundResource(R.drawable.ic_pause);
            updateSeekBar();
        }
    }

    private void playNextSong() {
        if (isShuffle) {
            currentSongIndex = new Random().nextInt(songs.length);
        } else {
            currentSongIndex = (currentSongIndex + 1) % songs.length;
        }
        initializeMediaPlayer();
        mediaPlayer.start();
        playPauseButton.setBackgroundResource(R.drawable.ic_pause);
        updateSeekBar();
    }

    private void playPreviousSong() {
        currentSongIndex = (currentSongIndex - 1 + songs.length) % songs.length;
        initializeMediaPlayer();
        mediaPlayer.start();
        playPauseButton.setBackgroundResource(R.drawable.ic_pause);
        updateSeekBar();
    }

    private void updateSeekBar() {
        handler.postDelayed(() -> {
            if (mediaPlayer != null && mediaPlayer.isPlaying()) {
                seekBar.setProgress(mediaPlayer.getCurrentPosition());
            }
            updateSeekBar();
        }, 1000);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (mediaPlayer != null) {
            mediaPlayer.release();
            mediaPlayer = null;
        }
    }
}
